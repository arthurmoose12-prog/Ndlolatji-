NDLOLATJI WEBSITE
=================

Files:
- index.html  : main website
- style.css   : design and responsive layout

How to use:
1. Keep index.html and style.css in the same folder.
2. Open index.html in a browser to preview the website.
3. Upload both files to a free static hosting service when ready.

Business details included:
Phone: 060 684 1924
Email: musaarthur12@gmail.com
Service area: Johannesburg & surrounding areas

The WhatsApp buttons use the business phone number and open a pre-filled quotation message.
